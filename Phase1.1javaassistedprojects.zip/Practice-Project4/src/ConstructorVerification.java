public class ConstructorVerification {
    private String name;
    private int age;

    public ConstructorVerification() {
        name = "Unknown";
        age = 0;
    }

    public ConstructorVerification(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public void displayInfo() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
    }

    public static void main(String[] args) {
        ConstructorVerification obj1 = new ConstructorVerification();
        ConstructorVerification obj2 = new ConstructorVerification("John Smith", 25);

        obj1.displayInfo();
        obj2.displayInfo();
    }
}

