public class MethodVerification {
    
    public static void methodWithNoParameters() {
        System.out.println("This is a method with no parameters.");
    }

    public static void methodWithParameters(String name, int age) {
        System.out.println("Hello, " + name + "! You are " + age + " years old.");
    }

    public static int methodWithReturnValue(int a, int b) {
        return a + b;
    }

    public static int[] methodWithMultipleReturnValues(int x, int y) {
        int sum = x + y;
        int difference = x - y;
        int[] results = {sum, difference};
        return results;
    }

    public static void main(String[] args) {
        methodWithNoParameters();
        methodWithParameters("John", 25);
        int result = methodWithReturnValue(5, 3);
        System.out.println("The result of methodWithReturnValue is: " + result);
        int[] values = methodWithMultipleReturnValues(10, 5);
        System.out.println("The sum is: " + values[0]);
        System.out.println("The difference is: " + values[1]);
    }
}


