class PublicClass {
    public void publicMethod() {
        System.out.println("This is a public method");
    }
}

class DefaultClass {
    void defaultMethod() {
        System.out.println("This is a default (package-private) method");
    }
}

class ProtectedClass {
    protected int protectedField;
    
    protected void protectedMethod() {
        System.out.println("This is a protected method");
    }
}

class PrivateClass {
    private String privateField;
    
    private void privateMethod() {
        System.out.println("This is a private method");
    }
}

public class AccessModifiersExample {
    public static void main(String[] args) {
        PublicClass publicObj = new PublicClass();
        publicObj.publicMethod();

        DefaultClass defaultObj = new DefaultClass();
        defaultObj.defaultMethod();

        ProtectedClass protectedObj = new ProtectedClass();
        protectedObj.protectedField = 42;
        protectedObj.protectedMethod();
    }
}


