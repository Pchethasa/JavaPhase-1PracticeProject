import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.List;

public class FileOperationsDemo {
    public static void main(String[] args) {
        // Create a new file
        File file = new File("example.txt");
        try {
            if (file.createNewFile()) {
                System.out.println("File created: " + file.getName());
            } else {
                System.out.println("File already exists.");
            }

            // Read the contents of the file
            List<String> lines = Files.readAllLines(Path.of("example.txt"));
            for (String line : lines) {
                System.out.println(line);
            }

            // Update the contents of the file
            Files.write(Path.of("example.txt"), "New content".getBytes(), StandardOpenOption.APPEND);

            // Delete the file
            if (file.delete()) {
                System.out.println("File deleted: " + file.getName());
            } else {
                System.out.println("Failed to delete the file.");
            }
        } catch (IOException e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }
}
