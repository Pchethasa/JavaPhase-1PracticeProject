
class Animal {
    public void eat() {
        System.out.println("The animal is eating.");
    }
}

// Define two interfaces
interface Herbivore {
    void eatPlants();
}

interface Carnivore {
    void eatMeat();
}

// Define two classes that implement the interfaces
class Deer extends Animal implements Herbivore {
    public void eatPlants() {
        System.out.println("The deer is eating plants.");
    }
}

class Lion extends Animal implements Carnivore {
    public void eatMeat() {
        System.out.println("The lion is eating meat.");
    }
}

// Define a class that resolves the diamond problem
class DeerLion implements Herbivore, Carnivore {
    public void eatPlants() {
        System.out.println("The deer-lion is eating plants.");
    }

    public void eatMeat() {
        System.out.println("The deer-lion is eating meat.");
    }
}

// Main class
public class DiamondProblemDemo {
    public static void main(String[] args) {
        Deer deer = new Deer();
        Lion lion = new Lion();
        DeerLion deerLion = new DeerLion();

        deer.eat();
        deer.eatPlants();

        lion.eat();
        lion.eatMeat();

        //deerLion.eat();
        deerLion.eatPlants();
        deerLion.eatMeat();
    }
}