class Car {
    // Define instance variables
    String brand;
    String color;
    int year;

    // Define a constructor
    public Car(String brand, String color, int year) {
        this.brand = brand;
        this.color = color;
        this.year = year;
    }

    // Define a method
    public void startEngine() {
        System.out.println("The " + brand + " car has started its engine.");
    }
}

// Main class
public class CarDemo {
    public static void main(String[] args) {
        // Create an object of the Car class
        Car myCar = new Car("Toyota", "Red", 2022);

        // Access instance variables and call methods
        System.out.println("My car is a " + myCar.brand + " " + myCar.color + " car from " + myCar.year + ".");
        myCar.startEngine();
    }
}

